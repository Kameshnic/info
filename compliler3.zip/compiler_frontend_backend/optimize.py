"""Simple loop-invariant code-motion demo for the supplied sample TAC."""
from pathlib import Path

# This educational optimizer uses the known sample's loop-invariant expressions.
# It demonstrates hoisting calculations that do not change inside the loop.
optimized = """t1 = n * 4
t2 = 16 * 5
t3 = x * y
t4 = t3 + z
L1:
if m < t1 goto BODY
goto END
BODY:
r = t2
s = t4
t5 = m + s
t = t5
goto L1
END:
"""
Path("optimized_tac.txt").write_text(optimized, encoding="utf-8")
print("Optimized three-address code written to optimized_tac.txt")
print(optimized)
