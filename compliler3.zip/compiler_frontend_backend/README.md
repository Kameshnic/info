# Mini Compiler Front End and Back End (LEX + YACC)

A simple college-lab demonstration for the given `while` loop and assignment program.

## Files

- `lexer.l` — LEX/Flex rules that identify keywords, identifiers, numbers, operators, and punctuation.
- `parser.y` — YACC/Bison grammar that checks syntax and emits basic three-address code (TAC).
- `sample.txt` — the sample source program.
- `optimize.py` — demonstrates loop-invariant code motion for this sample and writes `optimized_tac.txt`.
- `backend.py` — converts optimized TAC into simple pseudo-assembly and writes `target_code.txt`.

> This is a small educational demo, not a production compiler. The optimizer demonstrates code motion for the supplied sample; it is intentionally kept easy to understand.

## Install tools (Ubuntu / WSL)

```bash
sudo apt update
sudo apt install flex bison gcc python3
```

## Compile the LEX/YACC program

Run these commands from this folder:

```bash
bison -d parser.y
flex lexer.l
gcc parser.tab.c lex.yy.c -o compiler -lfl
```

## Run it

```bash
./compiler sample.txt
```

If syntax is valid, the program prints a syntax message and TAC, and saves the generated TAC to `tac.txt`.

Then run the optimizer and back end:

```bash
python3 optimize.py
python3 backend.py
```

Outputs:
- `tac.txt` — TAC emitted by the parser.
- `optimized_tac.txt` — code-motion result.
- `target_code.txt` — pseudo target code.

## Expected optimization idea

Inside the loop, `16 * 5` and `x * y + z` do not depend on a variable modified in the loop, so their calculations can be moved before the loop. The expression `n * 4` in the condition can also be computed before the loop if `n` is not modified in the loop. The expression `m + s` stays inside because `m` may change between loop iterations.

## Sample input

```c
while (m < n * 4)
{
    r = 16 * 5;
    s = x * y + z;
    t = m + s;
}
```

## Notes

- The generated target code is readable pseudo-assembly (`LOAD`, `ADD`, `MUL`, `CMP`, `JMP`, etc.), not machine code for a specific processor.
- The source sample does not update `m`, so as written, if `m < n * 4` is initially true, the loop does not terminate. This lab example is for compiler translation, not program execution.
- If Bison reports a shift/reduce conflict, it is related to expression precedence in the compact grammar; the `%left` declarations specify the intended arithmetic precedence.
