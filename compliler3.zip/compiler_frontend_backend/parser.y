%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int yylex(void);
void yyerror(const char *s);
extern FILE *yyin;
int temp_count = 1;
int label_count = 1;
char tac[20000] = "";
char *newtemp(void) { char b[32]; sprintf(b, "t%d", temp_count++); return strdup(b); }
char *newlabel(void) { char b[32]; sprintf(b, "L%d", label_count++); return strdup(b); }
void emit(const char *s) { strcat(tac, s); strcat(tac, "\n"); }
%}
%union { int num; char *str; }
%token WHILE
%token <num> NUMBER
%token <str> ID
%token EQ LE GE NE
%type <str> expr
%left '+' '-'
%left '*' '/'
%%
program : statement { printf("Syntax is correct.\n\nThree-address code:\n%s", tac); FILE *f=fopen("tac.txt","w"); if(f){fputs(tac,f); fclose(f);} }
        ;
statement : WHILE '(' condition ')' '{' statements '}' { emit("goto L1"); emit("END:"); }
          ;
condition : expr '<' expr { char line[256]; sprintf(line, "if %s < %s goto BODY", $1, $3); emit("L1:"); emit(line); emit("goto END"); emit("BODY:"); }
          | expr '>' expr { char line[256]; sprintf(line, "if %s > %s goto BODY", $1, $3); emit("L1:"); emit(line); emit("goto END"); emit("BODY:"); }
          | expr EQ expr { char line[256]; sprintf(line, "if %s == %s goto BODY", $1, $3); emit("L1:"); emit(line); emit("goto END"); emit("BODY:"); }
          ;
statements : statements assignment
           | assignment
           ;
assignment : ID '=' expr ';' { char line[256]; sprintf(line, "%s = %s", $1, $3); emit(line); }
           ;
expr : expr '+' expr { char *t=newtemp(); char b[256]; sprintf(b,"%s = %s + %s",t,$1,$3); emit(b); $$=t; }
     | expr '-' expr { char *t=newtemp(); char b[256]; sprintf(b,"%s = %s - %s",t,$1,$3); emit(b); $$=t; }
     | expr '*' expr { char *t=newtemp(); char b[256]; sprintf(b,"%s = %s * %s",t,$1,$3); emit(b); $$=t; }
     | expr '/' expr { char *t=newtemp(); char b[256]; sprintf(b,"%s = %s / %s",t,$1,$3); emit(b); $$=t; }
     | '(' expr ')' { $$=$2; }
     | ID { $$=$1; }
     | NUMBER { char b[32]; sprintf(b,"%d",$1); $$=strdup(b); }
     ;
%%
void yyerror(const char *s) { fprintf(stderr, "Syntax error: %s\n", s); }
int main(int argc, char **argv) {
    if(argc > 1) { yyin=fopen(argv[1],"r"); if(!yyin){perror(argv[1]); return 1;} }
    yyparse();
    return 0;
}
