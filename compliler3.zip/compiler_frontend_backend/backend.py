"""Tiny educational back end: translate optimized TAC to pseudo target code."""
from pathlib import Path

source = Path("optimized_tac.txt").read_text(encoding="utf-8").splitlines()
out = ["; Target code (simple pseudo-assembly)"]
for raw in source:
    line = raw.strip()
    if not line:
        continue
    if line.endswith(":"):
        out.append(line)
    elif line.startswith("if ") and " goto " in line:
        # Example: if m < t1 goto BODY
        cond, label = line[3:].split(" goto ", 1)
        left, op, right = cond.split()
        out += [f"CMP {left}, {right}", f"J{ {'<':'LT','>':'GT','==':'EQ','!=':'NE','<=':'LE','>=':'GE'}.get(op,'?') } {label}"]
    elif line.startswith("goto "):
        out.append("JMP " + line[5:])
    elif " = " in line:
        dest, expr = line.split(" = ", 1)
        parts = expr.split()
        if len(parts) == 1:
            out.append(f"MOV {dest}, {parts[0]}")
        elif len(parts) == 3:
            a, op, b = parts
            opcode = {"+":"ADD", "-":"SUB", "*":"MUL", "/":"DIV"}.get(op, "OP")
            out += [f"LOAD R1, {a}", f"{opcode} R1, {b}", f"STORE {dest}, R1"]
        else:
            out.append(f"; Untranslated: {line}")
    else:
        out.append("; " + line)
Path("target_code.txt").write_text("\\n".join(out) + "\\n", encoding="utf-8")
print("Target code written to target_code.txt")
print("\\n".join(out))
