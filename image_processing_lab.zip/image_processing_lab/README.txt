IMAGE PROCESSING LAB - HOW TO USE
===================================

Contents
--------
- image_processing_lab.py : one complete Python file with numbered sections.
- README.txt              : setup and command-line instructions.

Topics included
---------------
1. Load and display image
2. Image enhancement with CLAHE
3. Denoising with median filter
4. PSNR calculation
5. BGR-to-HSV conversion and H/S/V channel display
6. Binary thresholding and morphological opening/closing
7. Connected components, area threshold, and component count
8. Saving output images

Ubuntu setup
------------
1. Open Terminal and go to the extracted folder:
   cd image_processing_lab

2. Install packages:
   python3 -m pip install opencv-python numpy matplotlib

3. Copy your image into the folder and name it image_example.jpg:
   cp "/full/path/to/your/image.jpg" ./image_example.jpg

   If your image is in Windows Downloads while using WSL, example:
   cp "/mnt/c/Users/YOUR_WINDOWS_NAME/Downloads/your-image.jpg" ./image_example.jpg

4. Open image_processing_lab.py and set:
   IMAGE_PATH = "image_example.jpg"

   Or use a full path, for example:
   IMAGE_PATH = "/home/YOUR_USERNAME/Pictures/image_example.jpg"

5. Run the file:
   python3 image_processing_lab.py

Jupyter Notebook
----------------
The deliverable is a single Python file, as requested. Each operation is separated
into numbered SECTION blocks. To run section-by-section in Jupyter, open the .py
file in a text editor and copy each section into a separate notebook cell. You can
also use %run image_processing_lab.py to execute the whole file in one cell.

Area threshold
--------------
AREA_THRESHOLD = 100 means only connected white regions with at least 100 pixels
are counted. Change this value to suit your image and assignment requirements.

PSNR note
---------
PSNR needs a reference image and a comparison image of the same size. This script
prints PSNR between the original and processed image as a similarity measure. For a
proper denoising benchmark, use a known clean image as reference and compare it with
a noisy or denoised version.

Connected components note
-------------------------
The background has label 0 and is excluded. Components are counted only if their
pixel area is greater than or equal to AREA_THRESHOLD. The result image displays
bounding boxes around components that pass the threshold.
