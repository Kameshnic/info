"""
IMAGE PROCESSING LAB - SINGLE PYTHON FILE
Topics:
1. Image enhancement
2. Denoising
3. PSNR calculation
4. HSV color space
5. Morphological operations
6. Connected components, area threshold, and component count

Ubuntu / Jupyter usage:
- Keep this as one .py file.
- Replace IMAGE_PATH below with the path to your input image.
- In Jupyter, run a section at a time by copying each numbered section into a notebook cell.
- Or run the entire file from the terminal using: python3 image_processing_lab.py

Example image path:
IMAGE_PATH = "/home/YOUR_USERNAME/Pictures/image_example.jpg"

Install required packages (Ubuntu):
    python3 -m pip install opencv-python numpy matplotlib

If you use a virtual environment, activate it before installing packages.
"""

# ========================= SECTION 0: IMPORTS AND CONFIGURATION ==================

import os
import cv2
import numpy as np
import matplotlib.pyplot as plt

# TODO: Put your actual image path here.
# Example: IMAGE_PATH = "/home/kamesh/image_example.jpg"
IMAGE_PATH = "image_example.jpg"

# Connected-component area threshold in pixels.
# Components with area >= AREA_THRESHOLD are counted as foreground objects.
AREA_THRESHOLD = 100

# Output folder for processed images.
OUTPUT_DIR = "image_processing_outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)


# ========================= SECTION 1: LOAD AND DISPLAY THE IMAGE =================
# Terminal command to run the whole Python file:
#   python3 image_processing_lab.py
#
# To copy an image into the current Ubuntu folder, use one of these:
#   cp "/path/to/your/image.jpg" ./image_example.jpg
#   cp "/mnt/c/Users/YOUR_WINDOWS_NAME/Pictures/image.jpg" ./image_example.jpg
#
# If your image is in another folder, change IMAGE_PATH above.

image = cv2.imread(IMAGE_PATH)

if image is None:
    raise FileNotFoundError(
        f"Could not read image: {IMAGE_PATH}\n"
        "Copy an image to this folder as image_example.jpg, or update IMAGE_PATH."
    )

# OpenCV loads color images in BGR order; convert to RGB for Matplotlib display.
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

plt.figure(figsize=(7, 5))
plt.imshow(image_rgb)
plt.title("1. Original Image")
plt.axis("off")
plt.show()

print("Original image shape (height, width, channels):", image.shape)
print("Original image saved/read from:", os.path.abspath(IMAGE_PATH))


# ========================= SECTION 2: IMAGE ENHANCEMENT ==========================
# Enhancement example: improve contrast using CLAHE on the L channel in LAB.
# CLAHE = Contrast Limited Adaptive Histogram Equalization.

lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
l_channel, a_channel, b_channel = cv2.split(lab)

clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
enhanced_l = clahe.apply(l_channel)

enhanced_lab = cv2.merge((enhanced_l, a_channel, b_channel))
enhanced_image = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2BGR)

cv2.imwrite(os.path.join(OUTPUT_DIR, "enhanced_image.png"), enhanced_image)

plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.imshow(image_rgb)
plt.title("Original")
plt.axis("off")
plt.subplot(1, 2, 2)
plt.imshow(cv2.cvtColor(enhanced_image, cv2.COLOR_BGR2RGB))
plt.title("2. Enhanced Image (CLAHE)")
plt.axis("off")
plt.tight_layout()
plt.show()


# ========================= SECTION 3: DENOISING ==================================
# Median blur is useful for salt-and-pepper noise. Gaussian blur reduces smooth noise.
# Change the method if your assignment specifies a particular filter.

denoised_image = cv2.medianBlur(enhanced_image, 5)
cv2.imwrite(os.path.join(OUTPUT_DIR, "denoised_image.png"), denoised_image)

plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(enhanced_image, cv2.COLOR_BGR2RGB))
plt.title("Enhanced Image")
plt.axis("off")
plt.subplot(1, 2, 2)
plt.imshow(cv2.cvtColor(denoised_image, cv2.COLOR_BGR2RGB))
plt.title("3. Denoised Image (Median Filter, 5x5)")
plt.axis("off")
plt.tight_layout()
plt.show()


# ========================= SECTION 4: PSNR =======================================
# PSNR compares a reference image with a noisy/processed image.
# Higher PSNR generally means less pixel-wise error.
# IMPORTANT: True denoising PSNR requires a clean reference image and a noisy version.
# Here, original image is used as the reference and denoised output as the test image,
# so this is a processing similarity score, not a true denoising benchmark.

def calculate_psnr(reference, compared):
    """Return PSNR in dB for two same-sized images."""
    if reference.shape != compared.shape:
        raise ValueError("PSNR images must have identical dimensions.")
    reference_f = reference.astype(np.float64)
    compared_f = compared.astype(np.float64)
    mse = np.mean((reference_f - compared_f) ** 2)
    if mse == 0:
        return float("inf")
    return 20 * np.log10(255.0 / np.sqrt(mse))

psnr_value = calculate_psnr(image, denoised_image)
print(f"4. PSNR between original and denoised image: {psnr_value:.2f} dB")
print("Note: For a valid denoising-quality PSNR, compare a known clean image to its noisy/denoised version.")


# ========================= SECTION 5: HSV COLOR SPACE ===========================
# HSV = Hue, Saturation, Value.
# OpenCV uses H in [0,179] and S,V in [0,255] for 8-bit images.

hsv_image = cv2.cvtColor(denoised_image, cv2.COLOR_BGR2HSV)
h_channel, s_channel, v_channel = cv2.split(hsv_image)

cv2.imwrite(os.path.join(OUTPUT_DIR, "hsv_hue.png"), h_channel)
cv2.imwrite(os.path.join(OUTPUT_DIR, "hsv_saturation.png"), s_channel)
cv2.imwrite(os.path.join(OUTPUT_DIR, "hsv_value.png"), v_channel)

plt.figure(figsize=(12, 8))
plt.subplot(2, 2, 1)
plt.imshow(cv2.cvtColor(denoised_image, cv2.COLOR_BGR2RGB))
plt.title("Input for HSV")
plt.axis("off")
plt.subplot(2, 2, 2)
plt.imshow(h_channel, cmap="gray")
plt.title("H: Hue")
plt.axis("off")
plt.subplot(2, 2, 3)
plt.imshow(s_channel, cmap="gray")
plt.title("S: Saturation")
plt.axis("off")
plt.subplot(2, 2, 4)
plt.imshow(v_channel, cmap="gray")
plt.title("V: Value / Brightness")
plt.axis("off")
plt.tight_layout()
plt.show()

print("5. Converted image to HSV color space.")


# ========================= SECTION 6: MORPHOLOGICAL OPERATIONS ====================
# Morphology works on binary images. Threshold the grayscale image first.
# Opening removes small foreground specks; closing fills small holes/gaps.

gray = cv2.cvtColor(denoised_image, cv2.COLOR_BGR2GRAY)
_, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

kernel = np.ones((3, 3), np.uint8)
opening = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=1)
closing = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel, iterations=1)

cv2.imwrite(os.path.join(OUTPUT_DIR, "binary_image.png"), binary)
cv2.imwrite(os.path.join(OUTPUT_DIR, "morphological_opening.png"), opening)
cv2.imwrite(os.path.join(OUTPUT_DIR, "morphological_closing.png"), closing)

plt.figure(figsize=(12, 8))
plt.subplot(2, 2, 1)
plt.imshow(gray, cmap="gray")
plt.title("Grayscale")
plt.axis("off")
plt.subplot(2, 2, 2)
plt.imshow(binary, cmap="gray")
plt.title("Binary (Otsu Threshold)")
plt.axis("off")
plt.subplot(2, 2, 3)
plt.imshow(opening, cmap="gray")
plt.title("Morphological Opening")
plt.axis("off")
plt.subplot(2, 2, 4)
plt.imshow(closing, cmap="gray")
plt.title("Morphological Closing")
plt.axis("off")
plt.tight_layout()
plt.show()

print("6. Morphological opening and closing completed.")


# ========================= SECTION 7: CONNECTED COMPONENTS + AREA THRESHOLD =======
# Connected components labels each connected white region in the binary image.
# Label 0 is the background and is not counted as an object.
# AREA_THRESHOLD controls the minimum pixel area for an object to be counted.

num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
    closing, connectivity=8
)

component_count = 0
component_details = []

# Draw rectangles around components that pass the area threshold.
result_image = cv2.cvtColor(closing, cv2.COLOR_GRAY2BGR)

for label_id in range(1, num_labels):  # start at 1 to skip background
    x = stats[label_id, cv2.CC_STAT_LEFT]
    y = stats[label_id, cv2.CC_STAT_TOP]
    width = stats[label_id, cv2.CC_STAT_WIDTH]
    height = stats[label_id, cv2.CC_STAT_HEIGHT]
    area = stats[label_id, cv2.CC_STAT_AREA]
    centroid_x, centroid_y = centroids[label_id]

    if area >= AREA_THRESHOLD:
        component_count += 1
        component_details.append({
            "label": int(label_id),
            "area_pixels": int(area),
            "x": int(x),
            "y": int(y),
            "width": int(width),
            "height": int(height),
            "centroid_x": round(float(centroid_x), 2),
            "centroid_y": round(float(centroid_y), 2),
        })
        cv2.rectangle(result_image, (x, y), (x + width, y + height), (0, 0, 255), 2)
        cv2.putText(
            result_image, str(label_id), (x, max(y - 5, 15)),
            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA
        )

print("7. Connected component analysis")
print("Total labels including background:", num_labels)
print("Total foreground components before area filtering:", num_labels - 1)
print("Area threshold (pixels):", AREA_THRESHOLD)
print("Number of components with area >= threshold:", component_count)

if component_details:
    print("\nComponents passing the threshold:")
    for item in component_details:
        print(item)
else:
    print("No components passed the area threshold. Try lowering AREA_THRESHOLD.")

cv2.imwrite(os.path.join(OUTPUT_DIR, "connected_components.png"), result_image)

plt.figure(figsize=(8, 6))
plt.imshow(cv2.cvtColor(result_image, cv2.COLOR_BGR2RGB))
plt.title(f"7. Components with area >= {AREA_THRESHOLD} pixels: {component_count}")
plt.axis("off")
plt.show()


# ========================= SECTION 8: SAVE SUMMARY / FINAL OUTPUT =================
print("\nAll sections completed.")
print("Output images are saved in:", os.path.abspath(OUTPUT_DIR))
print("Files created:")
for filename in sorted(os.listdir(OUTPUT_DIR)):
    print(" -", filename)


# ========================= QUICK COMMAND-LINE REFERENCE ===========================
# 1. Check Python:
#    python3 --version
# 2. Install packages:
#    python3 -m pip install opencv-python numpy matplotlib
# 3. Copy image into this directory:
#    cp "/path/to/image.jpg" ./image_example.jpg
# 4. Run script:
#    python3 image_processing_lab.py
# 5. If permission is denied when copying, check the source path and destination folder.
# 6. In Jupyter Notebook, launch:
#    jupyter notebook
#    Then create a notebook and copy/run each SECTION separately if you need cell-by-cell output.
