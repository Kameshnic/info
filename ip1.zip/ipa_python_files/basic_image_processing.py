"""Exercise 1: Basic image processing operations (from the supplied PDF)."""
import cv2
import numpy as np
import matplotlib.pyplot as plt
from base import IMAGE_PATH, load_image, save_image, show_images, OUTPUT_DIR


def main():
    image = load_image(IMAGE_PATH)
    resized = cv2.resize(image, (256, 256))
    gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
    float_image = resized.astype(np.float32)
    _, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
    blue, green, red = cv2.split(resized)
    synthetic_red = np.zeros((256, 256, 3), dtype=np.uint8)
    synthetic_red[:, :, 2] = 255
    gradient = np.tile(np.arange(256, dtype=np.uint8), (256, 1))
    gradient_image = cv2.merge([gradient, gradient, gradient])
    rng = np.random.default_rng()
    noise = rng.normal(0, 25, gradient_image.shape).astype(np.float32)
    noisy_gaussian = np.clip(gradient_image.astype(np.float32) + noise, 0, 255).astype(np.uint8)
    outputs = {
        "resized.jpg": resized, "grayscale.jpg": gray, "binary.jpg": binary,
        "red_channel.jpg": red, "green_channel.jpg": green, "blue_channel.jpg": blue,
        "synthetic_red.jpg": synthetic_red, "gradient.jpg": gradient_image,
        "noisy_gaussian.jpg": noisy_gaussian,
    }
    for name, img in outputs.items(): save_image(name, img)
    show_images([resized, gray, binary, red, green, blue, synthetic_red, gradient_image, noisy_gaussian],
                ["Resized 256x256", "Grayscale", "Binary", "Red channel", "Green channel",
                 "Blue channel", "Synthetic red", "Horizontal gradient", "Gaussian noise"], cols=3)
    print("float32 image shape:", float_image.shape, "dtype:", float_image.dtype)

if __name__ == "__main__": main()
