"""Spatial-domain filters and noise experiments based on the supplied PDF."""
import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.metrics import mean_squared_error, peak_signal_noise_ratio
from base import IMAGE_PATH, load_image, save_image, show_images, OUTPUT_DIR

def add_uniform_noise(image, low=-30, high=30):
    noise = np.random.uniform(low, high, image.shape).astype(np.float32)
    return np.clip(image.astype(np.float32) + noise, 0, 255).astype(np.uint8)
def add_gaussian_noise(image, mean=0, sigma=25):
    noise = np.random.normal(mean, sigma, image.shape).astype(np.float32)
    return np.clip(image.astype(np.float32) + noise, 0, 255).astype(np.uint8)
def add_salt_pepper_noise(image, amount=0.04, salt_ratio=0.5):
    noisy = image.copy(); h,w = image.shape[:2]; n = int(amount*h*w)
    coords = (np.random.randint(0,h,n), np.random.randint(0,w,n))
    noisy[coords] = 255
    n_pepper = int(n*(1-salt_ratio)); coords = (np.random.randint(0,h,n_pepper),np.random.randint(0,w,n_pepper)); noisy[coords] = 0
    return noisy

def main():
    original = cv2.resize(load_image(IMAGE_PATH), (256,256))
    noisy_images = {"Uniform noise":add_uniform_noise(original), "Gaussian noise":add_gaussian_noise(original), "Salt and pepper":add_salt_pepper_noise(original)}
    all_imgs=[original]; titles=["Original"]
    for noise_name,noisy in noisy_images.items():
        save_image(noise_name.lower().replace(" ","_")+".jpg",noisy)
        for k in (3,5,7):
            results={"Box":cv2.blur(noisy,(k,k)), "Gaussian":cv2.GaussianBlur(noisy,(k,k),0), "Median":cv2.medianBlur(noisy,k)}
            for filter_name,result in results.items():
                save_image(f"{noise_name.lower().replace(' ','_')}_{filter_name.lower()}_{k}x{k}.jpg",result)
                if k==5: all_imgs.append(result); titles.append(f"{noise_name}: {filter_name} 5x5")
        print(f"{noise_name}: MSE={mean_squared_error(original,noisy):.2f}, PSNR={peak_signal_noise_ratio(original,noisy,data_range=255):.2f} dB")
    show_images(all_imgs,titles,cols=3,figsize=(15,10))
if __name__ == "__main__": main()
