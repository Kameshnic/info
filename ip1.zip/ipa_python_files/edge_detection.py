"""Exercise 8: Manual Roberts, Sobel, Prewitt, Laplacian and Canny edges."""
import cv2
import numpy as np
from base import EDGE_IMAGE_PATH, IMAGE_PATH, load_image, save_image, show_images, normalize_0_255

def conv2d_manual(image, kernel):
    image = image.astype(np.float32); kernel = np.asarray(kernel,dtype=np.float32)
    kh,kw=kernel.shape; pad_y,pad_x=kh//2,kw//2
    padded=cv2.copyMakeBorder(image,pad_y,pad_y,pad_x,pad_x,cv2.BORDER_REFLECT)
    out=np.zeros_like(image,dtype=np.float32)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]): out[y,x]=np.sum(padded[y:y+kh,x:x+kw]*kernel)
    return out,normalize_0_255(out)
def gradient_magnitude_direction(gx,gy): return np.hypot(gx,gy),np.arctan2(gy,gx)
def roberts_manual(img):
    gx,_=conv2d_manual(img,np.array([[1,0],[0,-1]],np.float32)); gy,_=conv2d_manual(img,np.array([[0,1],[-1,0]],np.float32)); mag=np.hypot(gx,gy); return mag,normalize_0_255(mag)
def sobel_manual(img):
    kx=np.array([[-1,0,1],[-2,0,2],[-1,0,1]],np.float32); ky=np.array([[-1,-2,-1],[0,0,0],[1,2,1]],np.float32)
    gx,_=conv2d_manual(img,kx); gy,_=conv2d_manual(img,ky); mag,ang=gradient_magnitude_direction(gx,gy)
    return {"gx":gx,"gy":gy,"mag":mag,"ang":ang,"gx_disp":normalize_0_255(gx),"gy_disp":normalize_0_255(gy),"mag_disp":normalize_0_255(mag)}
def prewitt_manual(img):
    kx=np.array([[-1,0,1],[-1,0,1],[-1,0,1]],np.float32); ky=np.array([[-1,-1,-1],[0,0,0],[1,1,1]],np.float32)
    gx,_=conv2d_manual(img,kx); gy,_=conv2d_manual(img,ky); mag,ang=gradient_magnitude_direction(gx,gy)
    return {"gx":gx,"gy":gy,"mag":mag,"ang":ang,"gx_disp":normalize_0_255(gx),"gy_disp":normalize_0_255(gy),"mag_disp":normalize_0_255(mag)}
def laplacian_manual(img,kernel_type="4n"):
    k=np.array([[0,1,0],[1,-4,1],[0,1,0]],np.float32) if kernel_type=="4n" else np.array([[1,1,1],[1,-8,1],[1,1,1]],np.float32)
    response,_=conv2d_manual(img,k); return response,normalize_0_255(response)
def canny_manual(img,low_ratio=.05,high_ratio=.15):
    blurred=cv2.GaussianBlur(img,(5,5),1.0); sob=sobel_manual(blurred); mag=sob['mag']; ang=sob['ang']; h,w=img.shape
    nms=np.zeros((h,w),np.float32); angle=(ang*180/np.pi)%180
    for y in range(1,h-1):
        for x in range(1,w-1):
            a=angle[y,x]; q=r=0
            if a<22.5 or a>=157.5: q,r=mag[y,x+1],mag[y,x-1]
            elif a<67.5: q,r=mag[y+1,x-1],mag[y-1,x+1]
            elif a<112.5: q,r=mag[y+1,x],mag[y-1,x]
            else: q,r=mag[y-1,x-1],mag[y+1,x+1]
            if mag[y,x]>=q and mag[y,x]>=r: nms[y,x]=mag[y,x]
    high=nms.max()*high_ratio; low=nms.max()*low_ratio
    strong=nms>=high; weak=(nms>=low)&(nms<high); edges=strong.copy()
    # Hysteresis: iteratively retain weak pixels connected to strong edges.
    while True:
        expanded=cv2.dilate(edges.astype(np.uint8),np.ones((3,3),np.uint8)).astype(bool)
        new=edges | (weak & expanded)
        if np.array_equal(new,edges): break
        edges=new
    return {"blurred":blurred,"mag":normalize_0_255(mag),"nms":normalize_0_255(nms),"edges":(edges*255).astype(np.uint8)}
def main():
    path=EDGE_IMAGE_PATH if EDGE_IMAGE_PATH.exists() else IMAGE_PATH
    gray=load_image(path,grayscale=True)
    roberts=roberts_manual(gray)[1]; sobel=sobel_manual(gray)['mag_disp']; prewitt=prewitt_manual(gray)['mag_disp']; lap=laplacian_manual(gray)[1]; canny=canny_manual(gray)['edges']
    builtin_sobel=cv2.Sobel(gray,cv2.CV_32F,1,1,ksize=3); builtin_sobel=normalize_0_255(builtin_sobel)
    builtin_canny=cv2.Canny(gray,50,150)
    items=[("input_gray.png",gray),("roberts_manual.png",roberts),("sobel_manual.png",sobel),("prewitt_manual.png",prewitt),("laplacian_manual.png",lap),("canny_manual.png",canny),("canny_opencv.png",builtin_canny)]
    for name,img in items: save_image(name,img)
    show_images([x[1] for x in items],[x[0].replace('.png','') for x in items],cols=3)
if __name__=="__main__": main()
