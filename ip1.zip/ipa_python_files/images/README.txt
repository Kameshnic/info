Copy your input image(s) into this folder.
Default general image: input.jpg
Optional exercise-specific names: ThermalImage.jpeg, img2.webp, edge.jpg, morphology.jpg
Change the path constants in ../base.py if your filenames or locations differ.
