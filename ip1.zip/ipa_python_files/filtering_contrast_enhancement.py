"""Exercise 3: Filtering and contrast enhancement for a thermal/night image."""
import cv2
import numpy as np
from skimage.metrics import structural_similarity, peak_signal_noise_ratio
from base import THERMAL_IMAGE_PATH, IMAGE_PATH, load_image, save_image, show_images


def contrast_stretching(image):
    image = image.astype(np.float32)
    lo, hi = float(image.min()), float(image.max())
    if hi == lo: return np.zeros_like(image, dtype=np.uint8)
    return np.clip((image - lo) * 255.0 / (hi - lo), 0, 255).astype(np.uint8)

def main():
    path = THERMAL_IMAGE_PATH if THERMAL_IMAGE_PATH.exists() else IMAGE_PATH
    source = load_image(path, grayscale=True)
    gaussian = cv2.GaussianBlur(source, (7, 7), 0)
    median = cv2.medianBlur(source, 7)
    stretched = contrast_stretching(gaussian)
    smooth = cv2.bilateralFilter(source, 9, 75, 75)
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]], dtype=np.float32)
    sharpened = cv2.filter2D(source, -1, kernel)
    for name, img in [("thermal_original.png",source),("gaussian_7x7.png",gaussian),
                      ("median_7x7.png",median),("contrast_stretched.png",stretched),
                      ("bilateral_smoothed.png",smooth),("sharpened.png",sharpened)]: save_image(name,img)
    show_images([source, gaussian, median, stretched, smooth, sharpened],
                ["Original", "Gaussian 7x7", "Median 7x7", "Contrast stretching", "Bilateral smoothing", "Sharpened"], cols=3)
    for title, result in [("Gaussian 7x7", gaussian), ("Median 7x7", median), ("Bilateral", smooth)]:
        print(f"{title}: SSIM={structural_similarity(source,result,data_range=255):.4f}, PSNR={peak_signal_noise_ratio(source,result,data_range=255):.2f} dB")
if __name__ == "__main__": main()
