"""Exercise 4: Histogram, PDF, CDF, manual equalization and histogram matching."""
import cv2
import numpy as np
import matplotlib.pyplot as plt
from base import HISTOGRAM_IMAGE_PATH, IMAGE_PATH, load_image, save_image, OUTPUT_DIR


def plot_hist(data, title, filename, ylabel="Frequency"):
    plt.figure(figsize=(8, 4)); plt.hist(data.ravel(), bins=256, range=(0,256), color="gray")
    plt.title(title); plt.xlabel("Pixel intensity"); plt.ylabel(ylabel); plt.xlim(0,255); plt.tight_layout()
    plt.savefig(OUTPUT_DIR / filename, dpi=150); plt.close()

def main():
    path = HISTOGRAM_IMAGE_PATH if HISTOGRAM_IMAGE_PATH.exists() else IMAGE_PATH
    image = load_image(path, grayscale=True)
    hist = np.bincount(image.ravel(), minlength=256)
    pdf = hist / image.size
    cdf = np.cumsum(pdf)
    mapping = np.round(255 * cdf).clip(0,255).astype(np.uint8)
    manual = mapping[image]
    builtin = cv2.equalizeHist(image)
    plot_hist(image, "Original histogram", "histogram_original.png")
    plt.figure(figsize=(8,4)); plt.plot(pdf); plt.title("PDF of pixel intensities"); plt.xlabel("Intensity"); plt.ylabel("Probability"); plt.tight_layout(); plt.savefig(OUTPUT_DIR/"pdf.png"); plt.close()
    plt.figure(figsize=(8,4)); plt.plot(cdf); plt.title("CDF of pixel intensities"); plt.xlabel("Intensity"); plt.ylabel("Cumulative probability"); plt.tight_layout(); plt.savefig(OUTPUT_DIR/"cdf.png"); plt.close()
    plot_hist(manual, "Manual equalized histogram", "histogram_manual_equalized.png")
    plot_hist(builtin, "OpenCV equalized histogram", "histogram_builtin_equalized.png")
    save_image("equalized_manual.png", manual); save_image("equalized_opencv.png", builtin)
    # Histogram matching/specification: map source CDF intensities to the closest target CDF intensity.
    target = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8)).apply(image)
    source_cdf = np.cumsum(np.bincount(image.ravel(), minlength=256) / image.size)
    target_cdf = np.cumsum(np.bincount(target.ravel(), minlength=256) / target.size)
    match_map = np.array([np.argmin(np.abs(target_cdf - value)) for value in source_cdf], dtype=np.uint8)
    matched = match_map[image]
    save_image("histogram_matched.png", matched)
    plt.figure(figsize=(12,7))
    for i,(im,title) in enumerate([(image,"Original"),(manual,"Manual equalization"),(builtin,"OpenCV equalization"),(target,"Target/CLAHE reference"),(matched,"Histogram matched")],1):
        plt.subplot(2,3,i); plt.imshow(im,cmap="gray"); plt.title(title); plt.axis("off")
    plt.tight_layout(); plt.savefig(OUTPUT_DIR/"histogram_comparison.png",dpi=150); plt.show()
    print("Pixel count:", hist.sum())
if __name__ == "__main__": main()
