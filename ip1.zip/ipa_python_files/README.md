# Image Processing and Analysis — Python lab files

This folder contains runnable Python scripts organized by the assignment titles in the supplied PDFs/DOCX:

- `base.py` — shared image paths, output directory, image loading/saving, display and normalization helpers.
- `basic_image_processing.py` — read/resize, grayscale/float32/binary conversion, RGB channels, synthetic red image, gradient and Gaussian noise.
- `filtering_contrast_enhancement.py` — Gaussian and median filters, contrast stretching, bilateral smoothing, sharpening, SSIM and PSNR.
- `histogram_equalization.py` — histogram, PDF, CDF, manual and OpenCV equalization, and histogram matching/specification demonstration.
- `spatial_domain_filters.py` — uniform/Gaussian/salt-and-pepper noise, box/Gaussian/median filters at 3x3, 5x5 and 7x7, MSE and PSNR.
- `edge_detection.py` — manual Roberts, Sobel, Prewitt, Laplacian and Canny-style edge detection, plus OpenCV Canny comparison.
- `morphological_operations.py` — thresholding, opening, closing and connected-component counting for microscope images.

## Ubuntu / Python Navigator setup

1. Extract this ZIP into a folder.
2. Open the folder in Python Navigator or your editor. The scripts can also be run in Ubuntu Terminal.
3. Install dependencies in the Python environment you will use:

   ```bash
   python3 -m pip install -r requirements.txt
   ```

4. Copy your image into the `images/` folder. The default is `images/input.jpg`.
5. Or edit the path constants near the top of `base.py` (`IMAGE_PATH`, `THERMAL_IMAGE_PATH`, `HISTOGRAM_IMAGE_PATH`, `EDGE_IMAGE_PATH`, `MORPHOLOGY_IMAGE_PATH`).
6. Run the required script from this folder, for example:

   ```bash
   python3 basic_image_processing.py
   python3 filtering_contrast_enhancement.py
   ```

Processed images and chart files are saved in `outputs/`.

## Important notes

- The PDFs refer to particular images such as `ThermalImage.jpeg` and `img2.webp`; those image files were not included in the uploads. Add your own relevant images or change the path in `base.py`.
- The spatial-domain-filter PDF appears image/scanned based, so the script implements the operations identifiable from the document's learning outcomes and page images: noise generation, box/Gaussian/median filters, and MSE/PSNR evaluation.
- The morphological script uses OpenCV morphology for a ready-to-run implementation of the listed opening/closing tasks. The estimated connected-component count depends on the input image and thresholding; it will not necessarily match the PDF's example count.
- `float_image` is created in the basic exercise as requested, but it is not saved as an image because standard image formats do not preserve float32 pixel data reliably. Save it as `.npy` if you need to preserve the numeric values.
