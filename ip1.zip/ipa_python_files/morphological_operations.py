"""Exercise 7: Morphological opening/closing for biological microscope images."""
import cv2
import numpy as np
from base import MORPHOLOGY_IMAGE_PATH, IMAGE_PATH, load_image, save_image, show_images

def structuring_element(shape="circle", size=5):
    shape_id={"circle":cv2.MORPH_ELLIPSE,"square":cv2.MORPH_RECT,"cross":cv2.MORPH_CROSS}.get(shape,cv2.MORPH_ELLIPSE)
    return cv2.getStructuringElement(shape_id,(size,size))
def opening(binary,se): return cv2.morphologyEx(binary,cv2.MORPH_OPEN,se)
def closing(binary,se): return cv2.morphologyEx(binary,cv2.MORPH_CLOSE,se)
def main():
    path=MORPHOLOGY_IMAGE_PATH if MORPHOLOGY_IMAGE_PATH.exists() else IMAGE_PATH
    gray=load_image(path,grayscale=True)
    # Otsu thresholding provides a practical starting point for microscope images.
    _,binary=cv2.threshold(gray,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
    se_circle=structuring_element("circle",5); opened=opening(binary,se_circle); restored=closing(opened,se_circle)
    n,labels,stats,centroids=cv2.connectedComponentsWithStats(restored,8)
    count=max(0,n-1)
    save_image("morph_thresholded.png",binary); save_image("rbc_after_opening.png",opened); save_image("rbc_after_closing.png",restored)
    show_images([binary,opened,restored],["Thresholded","After opening (noise removed)","After closing (restored)"],cols=3)
    se_square=structuring_element("square",7); cleaned=closing(binary,se_square); highlighted=opening(cleaned,se_square)
    save_image("tissue_after_closing.png",cleaned); save_image("tissue_after_opening.png",highlighted)
    se_cross=structuring_element("cross",5); bacteria_open=opening(binary,se_cross); bacteria_close=closing(bacteria_open,se_cross)
    save_image("bacteria_after_opening.png",bacteria_open); save_image("bacteria_after_closing.png",bacteria_close)
    show_images([binary,cleaned,highlighted,bacteria_open,bacteria_close],["Thresholded","Tissue closing","Tissue opening","Bacteria opening","Bacteria closing"],cols=3)
    print("Estimated connected components (not guaranteed to equal biological cell count):",count)
if __name__=="__main__": main()
