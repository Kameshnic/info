"""Shared configuration and helper functions for the Image Processing lab files.

Put your input image at images/input.jpg, or edit IMAGE_PATH below.
Run scripts from this folder, for example: python3 basic_image_processing.py
"""
from pathlib import Path
import cv2
import matplotlib.pyplot as plt

BASE_DIR = Path(__file__).resolve().parent
IMAGE_DIR = BASE_DIR / "images"
OUTPUT_DIR = BASE_DIR / "outputs"
IMAGE_PATH = IMAGE_DIR / "input.jpg"  # <-- CHANGE THIS to your image path if needed
THERMAL_IMAGE_PATH = IMAGE_DIR / "ThermalImage.jpeg"
HISTOGRAM_IMAGE_PATH = IMAGE_DIR / "img2.webp"
MORPHOLOGY_IMAGE_PATH = IMAGE_DIR / "morphology.jpg"
EDGE_IMAGE_PATH = IMAGE_DIR / "edge.jpg"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def load_image(path=IMAGE_PATH, grayscale=False):
    """Read an image and raise a helpful error if the path is wrong."""
    path = Path(path).expanduser()
    flag = cv2.IMREAD_GRAYSCALE if grayscale else cv2.IMREAD_COLOR
    image = cv2.imread(str(path), flag)
    if image is None:
        raise FileNotFoundError(
            f"Could not read image: {path}\n"
            f"Put an image in {IMAGE_DIR} or edit IMAGE_PATH in base.py."
        )
    return image

def save_image(filename, image):
    """Save an image in outputs/ and return its path."""
    path = OUTPUT_DIR / filename
    if not cv2.imwrite(str(path), image):
        raise OSError(f"Could not save image to {path}")
    print(f"Saved: {path}")
    return path

def show_images(images, titles, cmap=None, cols=3, figsize=(14, 8)):
    """Display a list of images with titles; BGR colour images are converted to RGB."""
    if len(images) != len(titles):
        raise ValueError("images and titles must have the same length")
    rows = (len(images) + cols - 1) // cols
    plt.figure(figsize=figsize)
    for i, (image, title) in enumerate(zip(images, titles), start=1):
        plt.subplot(rows, cols, i)
        if image.ndim == 3:
            plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        else:
            plt.imshow(image, cmap=cmap or "gray")
        plt.title(title)
        plt.axis("off")
    plt.tight_layout()
    plt.show()

def normalize_0_255(array):
    """Scale an array to displayable uint8 intensity values safely."""
    import numpy as np
    arr = np.asarray(array, dtype=np.float32)
    lo, hi = float(np.min(arr)), float(np.max(arr))
    if hi <= lo:
        return np.zeros(arr.shape, dtype=np.uint8)
    return np.clip((arr - lo) * (255.0 / (hi - lo)), 0, 255).astype(np.uint8)
