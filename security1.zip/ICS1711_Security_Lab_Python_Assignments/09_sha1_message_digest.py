"""Assignment document: 7 sha 1.pdf
ICS1711 - Security Laboratory | Experiment 7: SHA-1 message digest
Includes digest generation, avalanche demonstration, comparison, and preprocessing.
SHA-1 is for lab study only; use SHA-256 or stronger for modern security.
"""

import hashlib


def sha1_digest(message):
    return hashlib.sha1(message.encode("utf-8")).hexdigest()


def binary_message(message):
    return "".join(format(byte, "08b") for byte in message.encode("utf-8"))


def preprocess_sha1(message):
    data = message.encode("utf-8")
    original_bit_length = len(data) * 8
    bits = binary_message(message) + "1"
    while len(bits) % 512 != 448:
        bits += "0"
    bits += format(original_bit_length, "064b")
    return bits


def show_digest():
    message = input("Enter a text message: ")
    if not message:
        print("Message cannot be empty.")
        return
    print("Original message:", message)
    print("SHA-1 digest:", sha1_digest(message))


def show_avalanche_effect():
    message = input("Enter the original message: ")
    if not message:
        print("Message cannot be empty.")
        return
    print("Character positions:")
    for index, char in enumerate(message):
        print(f"{index}: {char!r}")
    try:
        index = int(input(f"Enter character position (0-{len(message) - 1}): "))
        if not 0 <= index < len(message):
            print("Invalid character position.")
            return
    except ValueError:
        print("Position must be an integer.")
        return
    replacement = input("Enter one different replacement character: ")
    if len(replacement) != 1 or replacement == message[index]:
        print("Enter exactly one different character.")
        return
    modified = message[:index] + replacement + message[index + 1:]
    print("Original SHA-1:", sha1_digest(message))
    print("Modified message:", modified)
    print("Modified SHA-1:", sha1_digest(modified))


def compare_messages():
    first = input("Enter first message: ")
    second = input("Enter second message: ")
    print("Message 1 SHA-1:", sha1_digest(first))
    print("Message 2 SHA-1:", sha1_digest(second))
    print("Result:", "Digests are identical." if sha1_digest(first) == sha1_digest(second)
          else "Digests are different.")


def show_preprocessing():
    message = input("Enter message for SHA-1 preprocessing: ")
    padded_bits = preprocess_sha1(message)
    print("Original message binary:", binary_message(message))
    print("Padded message length:", len(padded_bits), "bits")
    print("Number of 512-bit blocks:", len(padded_bits) // 512)
    print("Padded binary message:", padded_bits)
    print("SHA-1 digest:", sha1_digest(message))


def main():
    while True:
        print("\n--- SHA-1 Message Digest ---")
        print("1. Generate SHA-1 digest")
        print("2. Demonstrate avalanche effect")
        print("3. Compare two messages")
        print("4. Show SHA-1 preprocessing")
        print("5. Exit")
        choice = input("Enter choice: ").strip()
        if choice == "1":
            show_digest()
        elif choice == "2":
            show_avalanche_effect()
        elif choice == "3":
            compare_messages()
        elif choice == "4":
            show_preprocessing()
        elif choice == "5":
            print("Program terminated.")
            break
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
