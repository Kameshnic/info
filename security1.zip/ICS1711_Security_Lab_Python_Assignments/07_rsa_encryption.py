"""Assignment document: 5 rsa encryption.pdf
ICS1711 - Security Laboratory | Experiment 5: RSA encryption/decryption with OAEP
Requires: python -m pip install pycryptodome
"""

from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP


def main():
    print("Generating a 2048-bit RSA key pair...")
    key = RSA.generate(2048)
    public_key = key.publickey()
    private_key = key

    plaintext = input("Enter plaintext (keep it short for RSA-OAEP): ")
    message = plaintext.encode("utf-8")

    encryptor = PKCS1_OAEP.new(public_key)
    try:
        ciphertext = encryptor.encrypt(message)
    except ValueError as error:
        print("Could not encrypt this message:", error)
        print("RSA-OAEP can encrypt only a limited number of bytes per operation.")
        return

    print("\nCiphertext (hex):", ciphertext.hex())
    decryptor = PKCS1_OAEP.new(private_key)
    recovered = decryptor.decrypt(ciphertext).decode("utf-8")
    print("Decrypted plaintext:", recovered)
    print("Verification:", "Success" if recovered == plaintext else "Failed")


if __name__ == "__main__":
    main()
