"""Assignment document: 4 aes algorithm.pdf
ICS1711 - Security Laboratory | Experiment 4: AES-128 using PyCryptodome
Educational demonstration follows the assignment's AES-ECB mode.
"""

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad


def main():
    plaintext = input("Enter plaintext: ")
    key_text = input("Enter 16-byte secret key (exactly 16 characters): ")
    key = key_text.encode("utf-8")
    if len(key) != 16:
        print("Error: key must encode to exactly 16 bytes.")
        return

    cipher = AES.new(key, AES.MODE_ECB)
    ciphertext = cipher.encrypt(pad(plaintext.encode("utf-8"), AES.block_size))
    print("\nPlaintext:", plaintext)
    print("Ciphertext (hex):", ciphertext.hex())

    decipher = AES.new(key, AES.MODE_ECB)
    recovered = unpad(decipher.decrypt(ciphertext), AES.block_size).decode("utf-8")
    print("Decrypted plaintext:", recovered)
    print("Verification:", "Success" if recovered == plaintext else "Failed")


if __name__ == "__main__":
    main()
