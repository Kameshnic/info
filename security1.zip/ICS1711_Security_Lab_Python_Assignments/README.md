# ICS1711 Security Laboratory — Python Assignment Files

These are separate, runnable Python files prepared from the uploaded assignment PDFs, with indentation corrected and simple input validation added.

## Assignment-to-code mapping

| Python file | Assignment document | Experiment |
|---|---|---|
| `01_caesar_cipher.py` | `1 ceaser cypher.pdf` | Experiment 1 — Caesar Cipher |
| `02_playfair_cipher.py` | `2 play fair cypher hill cipher.pdf` | Experiment 1(b) — Playfair Cipher |
| `03_hill_cipher.py` | `2 play fair cypher hill cipher.pdf` | Experiment 1(b) — Hill Cipher |
| `04_rail_fence_row_column_major.py` | `3 rail fence technique.pdf` | Experiment 2 — Row-major and column-major transformation |
| `05_des_algorithm.py` | `3 des algorihtm.pdf` | Experiment 3 — DES |
| `06_aes_algorithm.py` | `4 aes algorithm.pdf` | Experiment 4 — AES |
| `07_rsa_encryption.py` | `5 rsa encryption.pdf` | Experiment 5 — RSA encryption |
| `08_diffie_hellman_key_exchange.py` | `6 diffie helman key exchange.pdf` | Experiment 6 — Diffie-Hellman key exchange |
| `09_sha1_message_digest.py` | `7 sha 1.pdf` | Experiment 7 — SHA-1 message digest |
| `10_md5_message_digest.py` | `8 mde 5.pdf` | Experiment 8 — MD5 message digest and file integrity monitor |
| `11_digital_signature_rsa_sha256.py` | `9 ds.pdf` | Experiment 9 — Digital Signature using RSA and SHA-256 |

## Setup

Use Python 3.10+ if possible. The Caesar, Playfair, Hill, Rail Fence, Diffie-Hellman, SHA-1, and MD5 files use only the Python standard library.

Install PyCryptodome for DES, AES, RSA encryption, and digital signatures:

```bash
python -m pip install pycryptodome
```

On Windows, run a file from the folder containing it with:

```bash
python 01_caesar_cipher.py
```

Replace the filename to run another assignment. In VS Code, open the `.py` file and click **Run Python File**. The indentation is already formatted using four spaces; avoid copying code from the PDF.

## MD5 file-integrity monitor

Run the MD5 program normally for the menu:

```bash
python 10_md5_message_digest.py
```

Run the monitor against a directory:

```bash
python 10_md5_message_digest.py --monitor .
```

It creates/updates `checksums.json` in the current working directory.

## Notes

- The SHA-1 and MD5 experiments are educational. Neither is recommended for modern security-sensitive use.
- The DES and AES examples retain ECB mode because that is what the uploaded lab documents specify. ECB is not recommended for real-world confidential data.
- The Diffie-Hellman example uses the sample values from the PDF when you enter `p=23`, `g=5`, Alice's private key `6`, and Bob's private key `15`; the shared key should be `2`.
- The uploaded `9 ds.pdf` states that the experiment is a Digital Signature System using RSA and SHA-256, but its program pages appear to repeat MD5 file-integrity code. `11_digital_signature_rsa_sha256.py` follows the stated aim/theory instead and includes key generation, signing, verification, tampering detection, and a simple e-mail demonstration.
- The Hill Cipher example follows the PDF's 2×2 matrix method and the sample key matrix `[[3, 3], [2, 5]]`.
- Classic ciphers (Caesar, Playfair, Hill, and Rail Fence) are for learning only, not modern secure communication.
