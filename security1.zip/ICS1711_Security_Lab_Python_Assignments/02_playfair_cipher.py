"""Assignment document: 2 play fair cypher hill cipher.pdf
ICS1711 - Security Laboratory | Experiment 1(b): Playfair Cipher
"""

ALPHABET = "ABCDEFGHIKLMNOPQRSTUVWXYZ"  # I and J share one cell


def generate_key_matrix(key):
    key = key.upper().replace("J", "I")
    letters = []
    for char in key + ALPHABET:
        if char in ALPHABET and char not in letters:
            letters.append(char)
    return [letters[i:i + 5] for i in range(0, 25, 5)]


def find_position(matrix, char):
    char = "I" if char == "J" else char
    for row in range(5):
        for col in range(5):
            if matrix[row][col] == char:
                return row, col
    raise ValueError(f"Character {char!r} is not in the key matrix.")


def preprocess(text):
    text = "".join(c for c in text.upper().replace("J", "I") if c.isalpha())
    result = []
    i = 0
    while i < len(text):
        first = text[i]
        if i + 1 >= len(text):
            result.extend([first, "X"])
            i += 1
        elif text[i + 1] == first:
            result.extend([first, "X"])
            i += 1
        else:
            result.extend([first, text[i + 1]])
            i += 2
    return "".join(result)


def transform_pair(matrix, first, second, decrypt=False):
    r1, c1 = find_position(matrix, first)
    r2, c2 = find_position(matrix, second)
    step = -1 if decrypt else 1

    if r1 == r2:
        return matrix[r1][(c1 + step) % 5] + matrix[r2][(c2 + step) % 5]
    if c1 == c2:
        return matrix[(r1 + step) % 5][c1] + matrix[(r2 + step) % 5][c2]
    return matrix[r1][c2] + matrix[r2][c1]


def encrypt(matrix, text):
    prepared = preprocess(text)
    return "".join(
        transform_pair(matrix, prepared[i], prepared[i + 1])
        for i in range(0, len(prepared), 2)
    )


def decrypt(matrix, ciphertext):
    text = "".join(c for c in ciphertext.upper().replace("J", "I") if c.isalpha())
    if len(text) % 2:
        raise ValueError("Ciphertext must contain an even number of letters.")
    return "".join(
        transform_pair(matrix, text[i], text[i + 1], decrypt=True)
        for i in range(0, len(text), 2)
    )


def main():
    keyword = input("Enter keyword: ")
    matrix = generate_key_matrix(keyword)
    print("\nKey matrix:")
    for row in matrix:
        print(" ".join(row))

    plaintext = input("\nEnter plaintext: ")
    ciphertext = encrypt(matrix, plaintext)
    print("Prepared plaintext:", preprocess(plaintext))
    print("Encrypted text:", ciphertext)
    print("Decrypted text (may contain filler X):", decrypt(matrix, ciphertext))


if __name__ == "__main__":
    main()
