"""Assignment document: 9 ds.pdf
ICS1711 - Security Laboratory | Experiment 9: Digital Signature using RSA + SHA-256
Requires: python -m pip install pycryptodome

Note: the uploaded PDF's program pages appear to contain duplicated MD5 file-integrity
code even though the experiment aim/theory describe RSA digital signatures. This file
implements the stated Experiment 9 aim.
"""

import os
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

PRIVATE_KEY_FILE = "sender_private.pem"
PUBLIC_KEY_FILE = "sender_public.pem"


def generate_keys():
    key = RSA.generate(2048)
    with open(PRIVATE_KEY_FILE, "wb") as file:
        file.write(key.export_key())
    with open(PUBLIC_KEY_FILE, "wb") as file:
        file.write(key.publickey().export_key())
    print(f"Private key saved to {PRIVATE_KEY_FILE}")
    print(f"Public key saved to {PUBLIC_KEY_FILE}")
    print("Keep the private key secret.")
    print("\nPublic key:\n", key.publickey().export_key().decode("utf-8"))


def load_private_key():
    if not os.path.exists(PRIVATE_KEY_FILE):
        raise FileNotFoundError("Private key not found. Choose Generate Keys first.")
    with open(PRIVATE_KEY_FILE, "rb") as file:
        return RSA.import_key(file.read())


def load_public_key():
    if not os.path.exists(PUBLIC_KEY_FILE):
        raise FileNotFoundError("Public key not found. Choose Generate Keys first.")
    with open(PUBLIC_KEY_FILE, "rb") as file:
        return RSA.import_key(file.read())


def sign_message(message):
    private_key = load_private_key()
    digest = SHA256.new(message.encode("utf-8"))
    return pkcs1_15.new(private_key).sign(digest)


def verify_message(message, signature):
    public_key = load_public_key()
    digest = SHA256.new(message.encode("utf-8"))
    try:
        pkcs1_15.new(public_key).verify(digest, signature)
        return True
    except (ValueError, TypeError):
        return False


def sign_interactive():
    message = input("Enter message to sign: ")
    try:
        signature = sign_message(message)
        print("SHA-256 digest:", SHA256.new(message.encode("utf-8")).hexdigest())
        print("Signature (hex):", signature.hex())
        with open("signature.hex", "w", encoding="utf-8") as file:
            file.write(signature.hex())
        print("Signature saved to signature.hex")
    except (FileNotFoundError, ValueError) as error:
        print(error)


def verify_interactive():
    message = input("Enter received message: ")
    signature_text = input("Enter signature in hex (or press Enter to load signature.hex): ").strip()
    if not signature_text:
        try:
            with open("signature.hex", "r", encoding="utf-8") as file:
                signature_text = file.read().strip()
        except OSError:
            print("signature.hex not found.")
            return
    try:
        signature = bytes.fromhex(signature_text)
        print("Signature verification:", "SUCCESS" if verify_message(message, signature) else "FAILED")
    except (ValueError, FileNotFoundError) as error:
        print("Could not verify signature:", error)


def demonstrate_tampering():
    message = input("Enter message to sign: ")
    try:
        signature = sign_message(message)
        modified = input("Enter modified message: ")
        print("Original message verification:", "SUCCESS" if verify_message(message, signature) else "FAILED")
        print("Modified message verification:", "SUCCESS" if verify_message(modified, signature) else "FAILED")
    except (FileNotFoundError, ValueError) as error:
        print(error)


def secure_email_demo():
    message = input("Alice's email message to Bob: ")
    try:
        signature = sign_message(message)
        print("\nBob verifies original message:",
              "SUCCESS" if verify_message(message, signature) else "FAILED")
        tampered = message + " (modified)"
        print("Bob verifies modified message:",
              "SUCCESS" if verify_message(tampered, signature) else "FAILED")
    except (FileNotFoundError, ValueError) as error:
        print(error)


def main():
    while True:
        print("\n--- Digital Signature System (RSA + SHA-256) ---")
        print("1. Generate and save RSA keys")
        print("2. Sign a message")
        print("3. Verify a signature")
        print("4. Demonstrate message tampering")
        print("5. Simulate secure e-mail")
        print("6. Exit")
        choice = input("Enter choice: ").strip()
        if choice == "1":
            generate_keys()
        elif choice == "2":
            sign_interactive()
        elif choice == "3":
            verify_interactive()
        elif choice == "4":
            demonstrate_tampering()
        elif choice == "5":
            secure_email_demo()
        elif choice == "6":
            print("Program terminated.")
            break
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
