"""Assignment document: 2 play fair cypher hill cipher.pdf
ICS1711 - Security Laboratory | Experiment 1(b): Hill Cipher (2x2 key)
"""


def mod_inverse(number, modulus):
    number %= modulus
    for candidate in range(1, modulus):
        if (number * candidate) % modulus == 1:
            return candidate
    return None


def inverse_key(key):
    a, b = key[0]
    c, d = key[1]
    determinant = (a * d - b * c) % 26
    inverse_determinant = mod_inverse(determinant, 26)
    if inverse_determinant is None:
        return None
    return [
        [(d * inverse_determinant) % 26, (-b * inverse_determinant) % 26],
        [(-c * inverse_determinant) % 26, (a * inverse_determinant) % 26],
    ]


def clean_text(text):
    text = "".join(char for char in text.upper() if char.isalpha())
    if len(text) % 2:
        text += "X"
    return text


def encrypt(text, key):
    text = clean_text(text)
    result = ""
    for index in range(0, len(text), 2):
        p1, p2 = ord(text[index]) - 65, ord(text[index + 1]) - 65
        c1 = (key[0][0] * p1 + key[0][1] * p2) % 26
        c2 = (key[1][0] * p1 + key[1][1] * p2) % 26
        result += chr(c1 + 65) + chr(c2 + 65)
    return result


def decrypt(ciphertext, inverse):
    if len(ciphertext) % 2:
        raise ValueError("Ciphertext length must be even.")
    result = ""
    ciphertext = ciphertext.upper()
    for index in range(0, len(ciphertext), 2):
        c1, c2 = ord(ciphertext[index]) - 65, ord(ciphertext[index + 1]) - 65
        p1 = (inverse[0][0] * c1 + inverse[0][1] * c2) % 26
        p2 = (inverse[1][0] * c1 + inverse[1][1] * c2) % 26
        result += chr(p1 + 65) + chr(p2 + 65)
    return result


def main():
    print("Enter the 2x2 key matrix values, one integer per prompt:")
    try:
        key = [
            [int(input("a: ")), int(input("b: "))],
            [int(input("c: ")), int(input("d: "))],
        ]
    except ValueError:
        print("Key values must be integers.")
        return

    inverse = inverse_key(key)
    if inverse is None:
        print("Invalid key matrix: determinant has no modular inverse modulo 26.")
        return

    plaintext = input("Enter plaintext: ")
    ciphertext = encrypt(plaintext, key)
    print("Encrypted text:", ciphertext)
    print("Decrypted text:", decrypt(ciphertext, inverse))


if __name__ == "__main__":
    main()
