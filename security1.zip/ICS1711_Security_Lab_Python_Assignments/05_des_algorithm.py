"""Assignment document: 3 des algorihtm.pdf
ICS1711 - Security Laboratory | Experiment 3: DES using PyCryptodome
Educational demonstration only: DES and ECB mode are not suitable for real security.
"""

from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad


def main():
    plaintext = input("Enter plaintext: ")
    key_text = input("Enter 8-byte secret key (exactly 8 characters): ")
    if len(key_text.encode("utf-8")) != 8:
        print("Error: key must encode to exactly 8 bytes.")
        return

    key = key_text.encode("utf-8")
    cipher = DES.new(key, DES.MODE_ECB)
    ciphertext = cipher.encrypt(pad(plaintext.encode("utf-8"), DES.block_size))
    print("\nPlaintext:", plaintext)
    print("Ciphertext (hex):", ciphertext.hex())

    decipher = DES.new(key, DES.MODE_ECB)
    recovered = unpad(decipher.decrypt(ciphertext), DES.block_size).decode("utf-8")
    print("Decrypted plaintext:", recovered)
    print("Verification:", "Success" if recovered == plaintext else "Failed")


if __name__ == "__main__":
    main()
