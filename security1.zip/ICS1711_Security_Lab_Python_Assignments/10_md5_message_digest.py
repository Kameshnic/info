"""Assignment document: 8 mde 5.pdf
ICS1711 - Security Laboratory | Experiment 8: MD5 message digest and file integrity monitor
Run normal menu: python 10_md5_message_digest.py
Run file monitor: python 10_md5_message_digest.py --monitor [directory]
MD5 is not suitable for security-sensitive use; file-monitor checksums here are for the lab.
"""

import hashlib
import json
import os
import sys

RECORD_FILE = "checksums.json"


def digest_text(message, algorithm="md5"):
    return hashlib.new(algorithm, message.encode("utf-8")).hexdigest()


def md5_digest(message):
    return digest_text(message, "md5")


def sha1_digest(message):
    return digest_text(message, "sha1")


def sha256_digest(message):
    return digest_text(message, "sha256")


def generate_md5():
    message = input("Enter a text message: ")
    if not message:
        print("Message cannot be empty.")
        return
    print("Original message:", message)
    print("MD5 digest:", md5_digest(message))


def verify_integrity():
    message = input("Enter the original text message: ")
    given = input("Enter the previously generated MD5 digest: ").strip().lower()
    calculated = md5_digest(message)
    print("Calculated MD5:", calculated)
    print("Result:", "Matches - integrity verified." if calculated == given
          else "Does Not Match - message may have changed.")


def avalanche_effect():
    first = input("Enter first message: ")
    second = input("Enter second message: ")
    print("Message 1 MD5:", md5_digest(first))
    print("Message 2 MD5:", md5_digest(second))
    print("A small input change should produce a substantially different digest.")


def calculate_file_md5(file_path):
    digest = hashlib.md5()
    with open(file_path, "rb") as file:
        for chunk in iter(lambda: file.read(4096), b""):
            digest.update(chunk)
    return digest.hexdigest()


def md5_file_checksum():
    path = input("Enter file path: ").strip()
    if not os.path.isfile(path):
        print("File does not exist.")
        return
    try:
        print("File:", path)
        print("MD5 checksum:", calculate_file_md5(path))
    except OSError as error:
        print("Unable to read file:", error)


def compare_hashes():
    message = input("Enter a text message: ")
    print("MD5    :", md5_digest(message), "(32 hex characters)")
    print("SHA-1  :", sha1_digest(message), "(40 hex characters)")
    print("SHA-256:", sha256_digest(message), "(64 hex characters)")


def load_records():
    if not os.path.exists(RECORD_FILE):
        return {}
    try:
        with open(RECORD_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
            return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}


def save_records(records):
    with open(RECORD_FILE, "w", encoding="utf-8") as file:
        json.dump(records, file, indent=4)


def file_integrity_monitor(directory="."):
    directory = os.path.abspath(directory)
    old_records = load_records()
    current_records = {}

    for filename in sorted(os.listdir(directory)):
        path = os.path.join(directory, filename)
        if os.path.isfile(path) and os.path.abspath(path) != os.path.abspath(RECORD_FILE):
            try:
                current_records[os.path.relpath(path, directory)] = calculate_file_md5(path)
            except OSError as error:
                print(f"Could not read {path}: {error}")

    for filename, checksum in current_records.items():
        if filename not in old_records:
            status = "New File"
        elif old_records[filename] == checksum:
            status = "Not Modified"
        else:
            status = "Modified"
        print(f"{status}: {filename}")

    for filename in old_records.keys() - current_records.keys():
        print(f"Missing File: {filename}")

    # Store the current state after reporting. The JSON file uses filename -> checksum.
    save_records(current_records)
    print(f"Updated checksum record: {os.path.abspath(RECORD_FILE)}")


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--monitor":
        directory = sys.argv[2] if len(sys.argv) > 2 else "."
        file_integrity_monitor(directory)
        return

    while True:
        print("\n--- MD5 Message Digest ---")
        print("1. Generate MD5")
        print("2. Verify message integrity")
        print("3. Demonstrate avalanche effect")
        print("4. Calculate file checksum")
        print("5. Compare MD5, SHA-1 and SHA-256")
        print("6. Exit")
        choice = input("Enter choice: ").strip()
        if choice == "1":
            generate_md5()
        elif choice == "2":
            verify_integrity()
        elif choice == "3":
            avalanche_effect()
        elif choice == "4":
            md5_file_checksum()
        elif choice == "5":
            compare_hashes()
        elif choice == "6":
            print("Program terminated.")
            break
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
