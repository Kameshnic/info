"""Assignment document: 1 ceaser cypher.pdf
ICS1711 - Security Laboratory | Experiment 1: Caesar Cipher
Includes encryption, decryption, and brute-force attack.
"""

def encrypt(text, key):
    result = ""
    key %= 26
    for char in text:
        if "A" <= char <= "Z":
            result += chr((ord(char) - ord("A") + key) % 26 + ord("A"))
        elif "a" <= char <= "z":
            result += chr((ord(char) - ord("a") + key) % 26 + ord("a"))
        else:
            result += char
    return result


def decrypt(text, key):
    return encrypt(text, -key)


def brute_force(ciphertext):
    print("\nTrying all possible keys:")
    for key in range(1, 26):
        print(f"Key {key}: {decrypt(ciphertext, key)}")


def main():
    while True:
        print("\n--- Caesar Cipher ---")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Brute Force Attack")
        print("4. Exit")
        choice = input("Enter choice: ").strip()

        if choice == "1":
            text = input("Enter plaintext: ")
            try:
                key = int(input("Enter key: "))
                print("Encrypted output:", encrypt(text, key))
            except ValueError:
                print("Key must be an integer.")
        elif choice == "2":
            text = input("Enter ciphertext: ")
            try:
                key = int(input("Enter key: "))
                print("Decrypted output:", decrypt(text, key))
            except ValueError:
                print("Key must be an integer.")
        elif choice == "3":
            brute_force(input("Enter ciphertext: "))
        elif choice == "4":
            print("Program terminated.")
            break
        else:
            print("Invalid choice. Enter 1, 2, 3, or 4.")


if __name__ == "__main__":
    main()
