"""Assignment document: 6 diffie helman key exchange.pdf
ICS1711 - Security Laboratory | Experiment 6: Diffie-Hellman key exchange
"""

def main():
    try:
        p = int(input("Enter the prime number p: "))
        g = int(input("Enter the primitive root g: "))
        private_a = int(input("Enter Alice's private key: "))
        private_b = int(input("Enter Bob's private key: "))
    except ValueError:
        print("Please enter integers only.")
        return

    if p <= 2 or not (1 < g < p) or private_a < 1 or private_b < 1:
        print("Use p > 2, 1 < g < p, and positive private keys.")
        return

    public_a = pow(g, private_a, p)
    public_b = pow(g, private_b, p)
    shared_a = pow(public_b, private_a, p)
    shared_b = pow(public_a, private_b, p)

    print("\nAlice Public Key:", public_a)
    print("Bob Public Key:", public_b)
    print("Key Computed By Alice:", shared_a)
    print("Key Computed By Bob:", shared_b)
    print("Verification Success" if shared_a == shared_b else "Verification Failed")


if __name__ == "__main__":
    main()
