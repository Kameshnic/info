"""Assignment document: 3 rail fence technique.pdf
ICS1711 - Security Laboratory | Experiment 2: Row-major and column-major transformations
"""

import math


def normalize(text):
    return text.upper().replace(" ", "")


def row_major_encrypt(text, cols):
    text = normalize(text)
    if cols < 1:
        raise ValueError("Number of columns must be positive.")
    rows = math.ceil(len(text) / cols) if text else 1
    text += "X" * (rows * cols - len(text))
    matrix = [["" for _ in range(cols)] for _ in range(rows)]
    index = 0
    for col in range(cols):
        for row in range(rows):
            matrix[row][col] = text[index]
            index += 1
    ciphertext = "".join(matrix[row][col] for row in range(rows) for col in range(cols))
    return matrix, ciphertext, rows


def row_major_decrypt(ciphertext, rows, cols):
    if rows < 1 or cols < 1 or len(ciphertext) != rows * cols:
        raise ValueError("Ciphertext length must equal rows multiplied by columns.")
    matrix = [["" for _ in range(cols)] for _ in range(rows)]
    index = 0
    for row in range(rows):
        for col in range(cols):
            matrix[row][col] = ciphertext[index]
            index += 1
    return "".join(matrix[row][col] for col in range(cols) for row in range(rows))


def column_major_encrypt(text, cols):
    text = normalize(text)
    if cols < 1:
        raise ValueError("Number of columns must be positive.")
    rows = math.ceil(len(text) / cols) if text else 1
    text += "X" * (rows * cols - len(text))
    matrix = [["" for _ in range(cols)] for _ in range(rows)]
    index = 0
    for row in range(rows):
        for col in range(cols):
            matrix[row][col] = text[index]
            index += 1
    ciphertext = "".join(matrix[row][col] for col in range(cols) for row in range(rows))
    return matrix, ciphertext, rows


def column_major_decrypt(ciphertext, rows, cols):
    if rows < 1 or cols < 1 or len(ciphertext) != rows * cols:
        raise ValueError("Ciphertext length must equal rows multiplied by columns.")
    matrix = [["" for _ in range(cols)] for _ in range(rows)]
    index = 0
    for col in range(cols):
        for row in range(rows):
            matrix[row][col] = ciphertext[index]
            index += 1
    return "".join(matrix[row][col] for row in range(rows) for col in range(cols))


def show_matrix(matrix):
    for row in matrix:
        print(" ".join(row))


def main():
    plaintext = input("Enter plaintext: ")
    try:
        cols = int(input("Enter number of columns: "))
        if cols < 1:
            raise ValueError
    except ValueError:
        print("Number of columns must be a positive integer.")
        return

    matrix1, cipher1, rows1 = row_major_encrypt(plaintext, cols)
    print("\nRow-major transformation matrix:")
    show_matrix(matrix1)
    print("Ciphertext:", cipher1)
    print("Decrypted text:", row_major_decrypt(cipher1, rows1, cols))

    matrix2, cipher2, rows2 = column_major_encrypt(plaintext, cols)
    print("\nColumn-major transformation matrix:")
    show_matrix(matrix2)
    print("Ciphertext:", cipher2)
    print("Decrypted text:", column_major_decrypt(cipher2, rows2, cols))
    print("Note: X characters may be padding added to complete the matrix.")


if __name__ == "__main__":
    main()
