# Computer Networks Lab — Simple Python Programs

These files are beginner-friendly Python versions of the concepts in the supplied CN lab PDFs (CN01–CN09), plus basic TCP and UDP examples.

## Run in Ubuntu

```bash
sudo apt update
sudo apt install python3 python3-pip
cd cn1_python_files
```

Run each server in one terminal and its client in another terminal.

### TCP echo (CN03)
Terminal 1:
```bash
python3 cn03_tcp_echo_server.py
```
Terminal 2:
```bash
python3 cn03_tcp_echo_client.py
```

### UDP DNS simulation (CN04)
Terminal 1:
```bash
python3 cn04_dns_server.py
```
Terminal 2:
```bash
python3 cn04_dns_client.py
```

### Checksum over TCP (CN05)
Terminal 1:
```bash
python3 cn05_checksum_server.py
```
Terminal 2:
```bash
python3 cn05_checksum_client.py
```

### Basic TCP (extra)
```bash
python3 basic_tcp_server.py
python3 basic_tcp_client.py
```

### Basic UDP (extra)
```bash
python3 basic_udp_server.py
python3 basic_udp_client.py
```

### HTTP client (CN02)
```bash
python3 cn02_http_client.py
```
This basic socket example uses plain HTTP on port 80. Many websites redirect to HTTPS or block plain HTTP; try a site that supports HTTP or use `http://example.com`.

### CN06 HTTP request/response inspection
```bash
python3 cn06_http_headers.py
```
Enter an HTTP URL. HTTPS URLs are not supported by this simple raw-socket example.

### CN07 UDP throughput and packet-loss demo
Terminal 1:
```bash
python3 cn07_udp_receiver.py
```
Terminal 2:
```bash
python3 cn07_udp_sender.py
```
This is a simple real UDP measurement demo, not an ns-3 simulation. Results depend on your local network and machine.

### CN08 congestion-window graph
Prepare `cwnd-trace.txt` with two columns: `time_seconds cwnd_bytes_or_segments`, then run:
```bash
python3 cn08_plot_cwnd.py
```
Install matplotlib if needed: `python3 -m pip install matplotlib`

### CN09 multi-user fairness calculation
```bash
python3 cn09_fairness.py
```
Enter per-user throughput values when prompted. This calculates Jain's fairness index; it is not a full ns-3 Wi-Fi simulation.

## Notes
- `127.0.0.1` means your own computer; use it for local practice.
- If you see “Address already in use”, stop the previous server with Ctrl+C or change the port.
- The PDFs for CN07–CN09 describe ns-3 C++ simulations. Python alone does not replace ns-3; the Python files here provide simple related measurement/plotting/analysis helpers.
- `cn01_system_calls.py` demonstrates Python equivalents of common socket operations. The system-call list in the original PDF is primarily C/POSIX material.
