"""CN05: TCP checksum server using a simple 8-bit checksum."""
import socket

HOST = "127.0.0.1"
PORT = 4444

def checksum(data):
    return sum(data) % 256

def receive_exact(conn, size):
    data = b""
    while len(data) < size:
        chunk = conn.recv(size - len(data))
        if not chunk:
            return None
        data += chunk
    return data

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(1)
        print(f"Checksum server listening on {HOST}:{PORT}")
        conn, address = server.accept()
        with conn:
            print("Client connected:", address)
            while True:
                raw_length = receive_exact(conn, 4)
                if raw_length is None:
                    break
                length = int.from_bytes(raw_length, "big")
                if length > 4096:
                    print("Message too large; closing connection.")
                    break
                message = receive_exact(conn, length)
                received_sum = receive_exact(conn, 1)
                if message is None or received_sum is None:
                    break
                correct = checksum(message) == received_sum[0]
                print("Message:", message.decode(errors="replace"))
                print("Checksum valid:", correct)
                conn.sendall(b"ACK" if correct else b"NAK")
    print("Server closed.")

if __name__ == "__main__":
    main()
