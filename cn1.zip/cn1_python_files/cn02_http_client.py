"""CN02: Simple HTTP client using a TCP socket (plain HTTP, port 80)."""
import socket
from urllib.parse import urlparse

def main():
    url = input("Enter an HTTP URL (example: http://example.com/): ").strip()
    if not url.startswith("http://"):
        print("Please enter a URL starting with http:// (this simple example does not support HTTPS).")
        return

    parsed = urlparse(url)
    host = parsed.hostname
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query
    if not host:
        print("Invalid URL.")
        return

    request = f"GET {path} HTTP/1.0\r\nHost: {host}\r\nConnection: close\r\n\r\n"
    try:
        with socket.create_connection((host, 80), timeout=8) as client:
            client.sendall(request.encode("ascii"))
            chunks = []
            while True:
                data = client.recv(4096)
                if not data:
                    break
                chunks.append(data)
        response = b"".join(chunks).decode("utf-8", errors="replace")
        headers, separator, body = response.partition("\r\n\r\n")
        status_line = headers.splitlines()[0] if headers else "No status line"
        print("Status:", status_line)
        with open("downloaded.html", "w", encoding="utf-8") as file:
            file.write(body if separator else response)
        print("HTML body saved to downloaded.html")
        print("\nHTML content (first 3000 characters):\n")
        print((body if separator else response)[:3000])
    except OSError as error:
        print("Connection failed:", error)

if __name__ == "__main__":
    main()
