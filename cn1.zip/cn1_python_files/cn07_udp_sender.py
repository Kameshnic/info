"""CN07: Send a burst of numbered UDP packets to the local receiver."""
import socket
import time

HOST = "127.0.0.1"
PORT = 7007

def main():
    count = int(input("Number of packets to send (e.g. 1000): ") or "1000")
    size = int(input("Packet size in bytes (e.g. 512): ") or "512")
    size = max(size, 4)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
        start = time.time()
        for sequence in range(count):
            header = sequence.to_bytes(4, "big")
            payload = b"x" * (size - 4)
            client.sendto(header + payload, (HOST, PORT))
            # Tiny delay prevents overwhelming a loopback receiver.
            time.sleep(0.0002)
        client.sendto(b"STOP", (HOST, PORT))
    print(f"Sent {count} packets in {time.time() - start:.3f} seconds.")
    print("Read the receiver terminal for throughput and packet-loss estimates.")

if __name__ == "__main__":
    main()
