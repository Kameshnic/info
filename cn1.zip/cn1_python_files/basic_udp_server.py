"""Extra: basic UDP server."""
import socket

HOST = "127.0.0.1"
PORT = 5001

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
        server.bind((HOST, PORT))
        print(f"UDP server listening on {HOST}:{PORT}")
        while True:
            data, address = server.recvfrom(1024)
            message = data.decode(errors="replace")
            print("Client:", message)
            server.sendto(("Server received: " + message).encode(), address)
            if message.lower() == "exit":
                break

if __name__ == "__main__":
    main()
