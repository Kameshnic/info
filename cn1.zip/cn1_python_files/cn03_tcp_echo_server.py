"""CN03: TCP echo server. Sends each received message back to the client."""
import socket

HOST = "127.0.0.1"
PORT = 12345

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(1)
        print(f"TCP echo server listening on {HOST}:{PORT}")
        conn, address = server.accept()
        with conn:
            print("Connected by", address)
            while True:
                data = conn.recv(1024)
                if not data:
                    break
                message = data.decode(errors="replace")
                print("Client:", message)
                conn.sendall(data)
                if message.strip().lower() == "exit":
                    break
    print("Server closed.")

if __name__ == "__main__":
    main()
