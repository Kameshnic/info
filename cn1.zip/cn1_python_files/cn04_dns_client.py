"""CN04: UDP DNS-table client with a small local cache and timeout."""
import socket

HOST = "127.0.0.1"
PORT = 5353

def main():
    cache = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
        client.settimeout(5)
        print("Commands: query <domain>, cache, exit")
        while True:
            command = input("> ").strip()
            if command.lower() == "exit":
                client.sendto(b"exit", (HOST, PORT))
                break
            if command == "cache":
                print(cache if cache else "Cache is empty")
                continue
            if not command.startswith("query "):
                print("Use: query example.com")
                continue
            domain = command[6:].strip().lower()
            if not domain:
                print("Please enter a domain.")
                continue
            if domain in cache:
                print("[Cache]", domain, "->", cache[domain])
                continue
            try:
                client.sendto(domain.encode(), (HOST, PORT))
                data, _ = client.recvfrom(1024)
                answer = data.decode(errors="replace")
                print(domain, "->", answer)
                if answer != "NXDOMAIN" and not answer.startswith("ERROR"):
                    cache[domain] = answer
            except socket.timeout:
                print("Server timed out.")

if __name__ == "__main__":
    main()
