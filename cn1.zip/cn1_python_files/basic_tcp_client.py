"""Extra: basic TCP client."""
import socket

HOST = "127.0.0.1"
PORT = 5000

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        client.connect((HOST, PORT))
        while True:
            message = input("Client: ")
            client.sendall(message.encode())
            if message.lower() == "exit":
                break
            print("Server:", client.recv(1024).decode(errors="replace"))

if __name__ == "__main__":
    main()
