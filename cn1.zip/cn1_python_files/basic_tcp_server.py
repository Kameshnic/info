"""Extra: basic TCP server."""
import socket

HOST = "127.0.0.1"
PORT = 5000

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(1)
        print(f"TCP server listening on {HOST}:{PORT}")
        conn, address = server.accept()
        with conn:
            print("Connected:", address)
            while True:
                data = conn.recv(1024)
                if not data:
                    break
                message = data.decode(errors="replace")
                print("Client:", message)
                conn.sendall(("Server received: " + message).encode())
                if message.lower() == "exit":
                    break

if __name__ == "__main__":
    main()
