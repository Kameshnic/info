"""CN03: TCP echo client."""
import socket

HOST = "127.0.0.1"
PORT = 12345

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        client.connect((HOST, PORT))
        print("Connected. Type exit to quit.")
        while True:
            message = input("You: ")
            client.sendall(message.encode())
            response = client.recv(1024)
            if not response:
                break
            print("Echo from server:", response.decode(errors="replace"))
            if message.lower() == "exit":
                break

if __name__ == "__main__":
    main()
