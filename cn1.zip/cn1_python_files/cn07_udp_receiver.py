"""CN07: Receive UDP test packets and estimate packet loss/throughput."""
import socket
import time

HOST = "127.0.0.1"
PORT = 7007

def main():
    expected = 0
    received = 0
    total_bytes = 0
    start = time.time()
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
        server.bind((HOST, PORT))
        server.settimeout(10)
        print(f"UDP measurement receiver on {HOST}:{PORT}; waiting for sender...")
        while True:
            try:
                data, address = server.recvfrom(2048)
            except socket.timeout:
                print("No packets received for 10 seconds; stopping.")
                break
            if data == b"STOP":
                break
            # Each test packet starts with a 4-byte sequence number.
            if len(data) >= 4:
                seq = int.from_bytes(data[:4], "big")
                expected = max(expected, seq + 1)
            received += 1
            total_bytes += len(data)
        elapsed = max(time.time() - start, 0.000001)
    lost = max(expected - received, 0)
    loss_percent = (lost / expected * 100) if expected else 0
    throughput_mbps = total_bytes * 8 / elapsed / 1_000_000
    print(f"Packets expected: {expected}")
    print(f"Packets received: {received}")
    print(f"Estimated packets lost: {lost}")
    print(f"Estimated loss: {loss_percent:.2f}%")
    print(f"Elapsed time: {elapsed:.3f} s")
    print(f"Throughput: {throughput_mbps:.3f} Mbps")

if __name__ == "__main__":
    main()
