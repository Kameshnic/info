"""CN06: Display a basic HTTP request/response and headers using a raw TCP socket."""
import socket
from urllib.parse import urlparse

def main():
    url = input("Enter plain HTTP URL (example: http://example.com/): ").strip()
    if not url.startswith("http://"):
        print("This simple raw-socket example supports http:// URLs only.")
        return
    parsed = urlparse(url)
    host = parsed.hostname
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query
    if not host:
        print("Invalid URL.")
        return
    request = f"GET {path} HTTP/1.0\r\nHost: {host}\r\nUser-Agent: CN-Lab-Python\r\nConnection: close\r\n\r\n"
    print("\nRequest sent:\n", request)
    try:
        with socket.create_connection((host, 80), timeout=8) as sock:
            sock.sendall(request.encode())
            response = b""
            while True:
                part = sock.recv(4096)
                if not part:
                    break
                response += part
        text = response.decode("utf-8", errors="replace")
        headers = text.split("\r\n\r\n", 1)[0]
        print("Response headers:\n")
        print(headers)
        with open("cn06_response.txt", "w", encoding="utf-8") as file:
            file.write(text)
        print("\nFull response saved to cn06_response.txt")
    except OSError as error:
        print("Request failed:", error)

if __name__ == "__main__":
    main()
