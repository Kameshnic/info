"""CN09: Calculate Jain's fairness index from per-user throughput values."""

def jains_fairness(values):
    if not values or sum(x * x for x in values) == 0:
        return 0.0
    return (sum(values) ** 2) / (len(values) * sum(x * x for x in values))

def main():
    raw = input("Enter throughput for each user, separated by spaces (e.g. 10 12 9 11): ")
    try:
        values = [float(item) for item in raw.split()]
    except ValueError:
        print("Please enter numbers separated by spaces.")
        return
    if not values or any(value < 0 for value in values):
        print("Enter one or more non-negative throughput values.")
        return
    total = sum(values)
    print("Number of users:", len(values))
    print("Aggregate throughput:", round(total, 3))
    print("Jain fairness index:", round(jains_fairness(values), 4))
    print("An index closer to 1 means throughput is more evenly shared.")

if __name__ == "__main__":
    main()
