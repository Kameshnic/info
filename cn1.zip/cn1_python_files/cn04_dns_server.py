"""CN04: Small UDP-based DNS-table simulation (not a real DNS server)."""
import socket

HOST = "127.0.0.1"
PORT = 5353
DNS_TABLE = {
    "example.com": "93.184.216.34",
    "openai.com": "104.20.19.94",
    "google.com": "142.250.190.14",
}

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
        server.bind((HOST, PORT))
        print(f"DNS demo server listening on {HOST}:{PORT}")
        while True:
            data, address = server.recvfrom(1024)
            domain = data.decode(errors="replace").strip().lower()
            print("Query:", domain, "from", address)
            if not domain or " " in domain:
                answer = "ERROR: Invalid format"
            else:
                answer = DNS_TABLE.get(domain, "NXDOMAIN")
            server.sendto(answer.encode(), address)
            if domain == "exit":
                break
    print("DNS demo server closed.")

if __name__ == "__main__":
    main()
