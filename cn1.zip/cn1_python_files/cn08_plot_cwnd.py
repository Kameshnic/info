"""CN08: Plot congestion window values from an ns-3 trace text file.
Input format: one pair per line, for example: 0.0 1
"""
try:
    import matplotlib.pyplot as plt
except ImportError:
    print("Install matplotlib first: python3 -m pip install matplotlib")
    raise SystemExit(1)

def main():
    times = []
    cwnd = []
    try:
        with open("cwnd-trace.txt", "r", encoding="utf-8") as file:
            for line in file:
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        times.append(float(parts[0]))
                        cwnd.append(float(parts[1]))
                    except ValueError:
                        continue
    except FileNotFoundError:
        print("Create cwnd-trace.txt in this folder with two columns: time cwnd")
        return
    if not times:
        print("No usable data found in cwnd-trace.txt")
        return
    plt.plot(times, cwnd, marker="o")
    plt.xlabel("Time (seconds)")
    plt.ylabel("Congestion window")
    plt.title("TCP Congestion Window over Time")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("cn08_cwnd_plot.png")
    print("Saved graph as cn08_cwnd_plot.png")
    plt.show()

if __name__ == "__main__":
    main()
