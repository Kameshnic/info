"""Extra: basic UDP client."""
import socket

HOST = "127.0.0.1"
PORT = 5001

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
        while True:
            message = input("Client: ")
            client.sendto(message.encode(), (HOST, PORT))
            if message.lower() == "exit":
                break
            data, _ = client.recvfrom(1024)
            print("Server:", data.decode(errors="replace"))

if __name__ == "__main__":
    main()
