"""CN01: Beginner-friendly demonstrations of Python socket equivalents.
The original PDF explains POSIX/C calls such as socket(), bind(), listen(),
accept(), connect(), send(), recv(), sendto(), recvfrom(), and close().
"""
import socket

def main():
    # socket() creates a communication endpoint.
    tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print("socket(): created TCP socket")

    # getsockname() shows the local address after binding to an available port.
    tcp_socket.bind(("127.0.0.1", 0))
    print("bind(): local address =", tcp_socket.getsockname())

    # close() releases the socket.
    tcp_socket.close()
    print("close(): TCP socket closed")

    # UDP uses SOCK_DGRAM; sendto()/recvfrom() are used for datagrams.
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    print("socket(): created UDP socket")
    udp_socket.close()
    print("close(): UDP socket closed")

    print("\nOther functions in the PDF:")
    print("listen() / accept() : TCP server waits for and accepts a client")
    print("connect()           : TCP client connects to a server")
    print("send() / recv()      : send and receive TCP data")
    print("sendto() / recvfrom(): send and receive UDP datagrams")
    print("htons()/htonl()      : C byte-order conversion functions; Python handles")
    print("                      socket address/port conversion in its socket API.")

if __name__ == "__main__":
    main()
