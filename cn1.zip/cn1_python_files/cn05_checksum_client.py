"""CN05: TCP client sends message length, message bytes, and checksum."""
import socket

HOST = "127.0.0.1"
PORT = 4444

def checksum(data):
    return sum(data) % 256

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        client.connect((HOST, PORT))
        print("Connected. Type exit to quit.")
        while True:
            message = input("Message: ")
            if message.lower() == "exit":
                break
            data = message.encode()
            check = checksum(data)
            # Optional demonstration: type a message containing 'error' to corrupt
            # the checksum intentionally, so the server responds NAK.
            if "error" in message.lower():
                check = (check + 1) % 256
                print("Checksum intentionally changed for demonstration.")
            packet = len(data).to_bytes(4, "big") + data + bytes([check])
            client.sendall(packet)
            reply = client.recv(16).decode(errors="replace")
            print("Server:", reply)
            if reply == "NAK":
                print("Please send the message again.")
    print("Client closed.")

if __name__ == "__main__":
    main()
